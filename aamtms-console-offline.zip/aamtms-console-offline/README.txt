AAM TMS 관제 화면 시안 - 오프라인 파일

사용법
1. 압축을 풂.
2. 폴더 안의 index.html을 브라우저(Chrome·Edge 권장)로 엶. 인터넷과 서버가 필요 없음.
3. 멀티모니터는 화면 상단 "멀티모니터"에서 구성함(같은 브라우저 창끼리 연동됨).

알아 둘 점
- 가상 데이터로 동작하는 참고용 시안임. 절차·기준값·상황은 모두 가상 예시이며 실제가 아님.
- 지도 배경(위성·일반)은 인터넷이 있을 때만 보이며, 연결이 없으면 격자 배경으로 표시함.
- 화면 언어는 오른쪽 위 KO/EN으로 바꿈. 기준 위치는 주소 뒤에 ?loc=jawoldo 등으로도 지정함.
- 새 버전은 공개 사이트에서 다시 받아야 함: https://simulda62.github.io/aamtms-console-demo/

Usage: unzip, then open index.html in a browser (Chrome/Edge recommended). No internet or server needed.
Map imagery needs internet; without it the grid basemap is shown. All data are fictional demo data.

시안 버전: 3ae60ce
